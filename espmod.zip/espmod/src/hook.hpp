#pragma once
#include <dobby.h>

// Single adapter over the inline-hook backend.
// Dobby master: int DobbyHook(void* address, void* fake_func, void** out_origin_func); 0 = success, -1 = failure.
// (No dobby_dummy_func_t typedef exists in this revision.)
inline bool install_hook(void* target, void* replacement, void** original) {
    if (!target || !replacement) return false;
    return DobbyHook(target, replacement, original) == 0;
}
