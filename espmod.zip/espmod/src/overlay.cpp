#include "common.hpp"
#include "hook.hpp"
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <dlfcn.h>
#include <algorithm>
#include <chrono>
#include <cstdio>
#include "imgui.h"
#include "backends/imgui_impl_opengl3.h"

namespace {

EGLBoolean (*g_origSwap)(EGLDisplay, EGLSurface) = nullptr;
std::atomic<uint64_t> g_swaps{0};

bool       g_inited   = false;
bool       g_menuOpen = false;
EGLContext g_ctx      = EGL_NO_CONTEXT;
EGLSurface g_surf     = EGL_NO_SURFACE;
std::chrono::steady_clock::time_point g_last;

bool init_imgui(int h) {
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    float scale = std::clamp(h / 450.0f, 1.5f, 4.0f);   // assumption: tuned for phone landscape
    ImGui::StyleColorsDark();
    ImGui::GetStyle().ScaleAllSizes(scale);
    io.FontGlobalScale = scale;
    if (!ImGui_ImplOpenGL3_Init("#version 300 es")) { LOGE("ImGui_ImplOpenGL3_Init failed"); return false; }
    g_last = std::chrono::steady_clock::now();
    LOGI("imgui ready, scale %.2f", scale);
    return true;
}

bool toggle(const char* label, std::atomic<bool>& v) {
    bool b = v;
    bool changed = ImGui::Checkbox(label, &b);
    if (changed) v = b;
    return changed;
}
bool slider(const char* label, std::atomic<float>& v, float lo, float hi) {
    float f = v;
    bool changed = ImGui::SliderFloat(label, &f, lo, hi, "%.1f");
    if (changed) v = f;
    return changed;
}

void draw_esp(const Snapshot& s, float sx, float sy, float H) {
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    for (const EspEntry& e : s.entries) {
        float fx = e.footX * sx, fy = H - e.footY * sy;
        float hx = e.headX * sx, hy = H - e.headY * sy;
        float bh = fy - hy;                  // box height in px
        if (bh < 4.0f) continue;
        float bw = bh * 0.45f, cx = (fx + hx) * 0.5f;
        float x0 = cx - bw * 0.5f, x1 = cx + bw * 0.5f;
        ImU32 col = e.teammate ? IM_COL32(60, 220, 90, 255) : IM_COL32(240, 60, 60, 255);
        float th = std::max(1.5f, ImGui::GetIO().FontGlobalScale);

        if (g_cfg.box) dl->AddRect(ImVec2(x0, hy), ImVec2(x1, fy), col, 0.0f, 0, th);
        if (g_cfg.health) {
            float f = std::clamp(e.health / 100.0f, 0.0f, 1.0f);   // assumption: max health 100
            float bx = x0 - 4.0f * th;
            dl->AddRectFilled(ImVec2(bx, hy), ImVec2(bx + 2.0f * th, fy), IM_COL32(0, 0, 0, 160));
            dl->AddRectFilled(ImVec2(bx, fy - bh * f), ImVec2(bx + 2.0f * th, fy), IM_COL32(60, 220, 90, 255));
        }
        char buf[64];
        float ty = hy - ImGui::GetFontSize() - 2.0f;
        if (g_cfg.name && e.name[0]) {
            snprintf(buf, sizeof buf, "%s", e.name);
            ImVec2 ts = ImGui::CalcTextSize(buf);
            dl->AddText(ImVec2(cx - ts.x * 0.5f, ty), IM_COL32(255, 255, 255, 255), buf);
        }
        if (g_cfg.distance) {
            snprintf(buf, sizeof buf, "%dm", (int)e.dist);
            ImVec2 ts = ImGui::CalcTextSize(buf);
            dl->AddText(ImVec2(cx - ts.x * 0.5f, fy + 2.0f), IM_COL32(255, 255, 255, 255), buf);
        }
    }
}

void draw_menu(const Snapshot& s, float W, float H) {
    ImGui::SetNextWindowPos(ImVec2(10, 10));
    ImGui::SetNextWindowBgAlpha(0.45f);
    ImGui::Begin("##tog", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
                 ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar);
    if (ImGui::Button(g_menuOpen ? "ESP [-]" : "ESP [+]")) g_menuOpen = !g_menuOpen;
    ImGui::End();

    if (!g_menuOpen) return;
    ImGui::SetNextWindowPos(ImVec2(10, H * 0.14f), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(W * 0.42f, H * 0.62f), ImGuiCond_FirstUseEver);
    ImGui::Begin("ESP");
    toggle("Enabled", g_cfg.masterEnable);
    toggle("Box", g_cfg.box);
    toggle("Name", g_cfg.name);
    toggle("Health", g_cfg.health);
    toggle("Distance", g_cfg.distance);
    toggle("Show teammates", g_cfg.showTeam);
    slider("Max dist", g_cfg.maxDistance, 20.0f, 500.0f);
    slider("Head offset", g_cfg.headOffset, 1.0f, 2.4f);
    ImGui::Separator();
    ImGui::TextWrapped("%s", s.status);
    ImGui::End();
}

void draw_frame(int w, int h) {
    Snapshot s;
    snapshot_copy(s);

    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2((float)w, (float)h);
    auto now = std::chrono::steady_clock::now();
    io.DeltaTime = std::clamp(std::chrono::duration<float>(now - g_last).count(), 0.001f, 0.1f);
    g_last = now;

    float sx = 1.0f, sy = 1.0f;
    if (s.screenW > 0 && s.screenH > 0) { sx = (float)w / s.screenW; sy = (float)h / s.screenH; }
    if (s.touch.valid) {   // Unity touch origin is bottom-left; ImGui is top-left
        io.AddMousePosEvent(s.touch.x * sx, (float)h - s.touch.y * sy);
        io.AddMouseButtonEvent(0, s.touch.down);
    }

    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();
    draw_esp(s, sx, sy, (float)h);
    draw_menu(s, (float)w, (float)h);
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}

EGLBoolean hooked_swap(EGLDisplay dpy, EGLSurface surf) {
    ++g_swaps;
    EGLContext ctx = eglGetCurrentContext();
    EGLint w = 0, h = 0;
    if (ctx != EGL_NO_CONTEXT) {
        eglQuerySurface(dpy, surf, EGL_WIDTH, &w);
        eglQuerySurface(dpy, surf, EGL_HEIGHT, &h);
    }
    if (w >= 480 && h >= 320) {   // skip tiny / auxiliary surfaces
        if (!g_inited) {
            g_ctx = ctx; g_surf = surf;
            g_inited = init_imgui(h);
            if (!g_inited) { g_ctx = EGL_NO_CONTEXT; g_surf = EGL_NO_SURFACE; }
        }
        if (g_inited && ctx == g_ctx && surf == g_surf) draw_frame(w, h);
    }
    return g_origSwap(dpy, surf);
}

} // namespace

bool overlay_install() {
    void* egl = dlopen("libEGL.so", RTLD_NOW);
    void* sym = egl ? dlsym(egl, "eglSwapBuffers") : nullptr;
    if (!sym) { LOGE("eglSwapBuffers not found"); return false; }
    if (!install_hook(sym, (void*)hooked_swap, (void**)&g_origSwap)) {
        LOGE("hook failed: eglSwapBuffers @ %p", sym);
        return false;
    }
    LOGI("hooked eglSwapBuffers @ %p", sym);
    return true;
}

uint64_t overlay_swap_count() { return g_swaps.load(); }
